# MIUI屏蔽更新

通过修改host实现屏蔽系统更新